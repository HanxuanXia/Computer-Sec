<?php
/**
 * 显示当前 2FA 验证码（临时工具）
 * 仅用于测试和开发环境
 */

require_once __DIR__ . '/includes/2fa.php';
require_once __DIR__ . '/config/database.php';

$email = 'admin@lovejoy.com';

$database = new Database();
$db = $database->getConnection();

$stmt = $db->prepare('SELECT two_factor_secret FROM users WHERE email = :email');
$stmt->execute(['email' => $email]);
$user = $stmt->fetch();

if (!$user || !$user['two_factor_secret']) {
    die('2FA 未启用');
}

// 生成当前验证码
$timestamp = floor(time() / 30);
$currentCode = generateTOTP($user['two_factor_secret'], $timestamp);

// 计算剩余时间
$now = time();
$timeInPeriod = $now % 30;
$timeLeft = 30 - $timeInPeriod;

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔐 当前验证码 - Lovejoy's Antiques</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 50px;
            max-width: 500px;
            width: 100%;
            text-align: center;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
            font-size: 28px;
        }
        .code-display {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            border-radius: 15px;
            margin: 30px 0;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
        }
        .code {
            font-family: 'Courier New', monospace;
            font-size: 64px;
            font-weight: bold;
            letter-spacing: 15px;
            margin: 20px 0;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        .timer {
            font-size: 24px;
            margin-top: 20px;
            opacity: 0.95;
        }
        .progress-bar {
            width: 100%;
            height: 8px;
            background: rgba(255,255,255,0.3);
            border-radius: 10px;
            overflow: hidden;
            margin-top: 15px;
        }
        .progress-fill {
            height: 100%;
            background: white;
            border-radius: 10px;
            transition: width 1s linear;
        }
        .info {
            background: #e3f2fd;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            border-left: 5px solid #2196f3;
        }
        .info p {
            color: #0d47a1;
            line-height: 1.6;
            margin-bottom: 10px;
            text-align: left;
        }
        .warning {
            background: #fff3cd;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            border-left: 5px solid #ffc107;
        }
        .warning p {
            color: #856404;
            font-size: 14px;
        }
        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        .btn {
            flex: 1;
            padding: 15px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            transition: transform 0.2s;
            display: inline-block;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .btn-secondary {
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
        }
        .btn:hover {
            transform: translateY(-2px);
        }
        .auto-refresh {
            color: #666;
            font-size: 12px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔐 当前 2FA 验证码</h1>
        <p style="color: #666; margin-bottom: 20px;">账户: <strong><?php echo htmlspecialchars($email); ?></strong></p>
        
        <div class="code-display">
            <p style="font-size: 18px; margin-bottom: 10px;">当前验证码</p>
            <div class="code" id="currentCode"><?php echo htmlspecialchars($currentCode); ?></div>
            <div class="timer">
                ⏱️ <span id="timeLeft"><?php echo $timeLeft; ?></span> 秒后刷新
            </div>
            <div class="progress-bar">
                <div class="progress-fill" id="progressBar"></div>
            </div>
        </div>
        
        <div class="info">
            <p><strong>📋 如何使用：</strong></p>
            <p>1. 复制上面的 6 位验证码</p>
            <p>2. 回到登录页面</p>
            <p>3. 在 "Verification Code" 输入框中粘贴验证码</p>
            <p>4. 点击 "Verify" 按钮</p>
            <p>5. 登录成功！🎉</p>
        </div>
        
        <div class="warning">
            <p><strong>⚠️ 注意：</strong> 此页面仅用于测试。在生产环境中，您应该使用 Google Authenticator App 获取验证码。</p>
        </div>
        
        <div class="btn-group">
            <a href="verify_2fa.php" class="btn btn-primary">🔐 返回验证页面</a>
            <a href="show_qr_code.php" class="btn btn-secondary">📱 查看 QR 码</a>
        </div>
        
        <p class="auto-refresh">⟳ 页面将在验证码过期后自动刷新</p>
    </div>
    
    <script>
        let timeLeft = <?php echo $timeLeft; ?>;
        
        function updateTimer() {
            timeLeft--;
            
            document.getElementById('timeLeft').textContent = timeLeft;
            
            // 更新进度条
            const percentage = (timeLeft / 30) * 100;
            document.getElementById('progressBar').style.width = percentage + '%';
            
            // 快要过期时变红
            if (timeLeft <= 5) {
                document.getElementById('timeLeft').style.color = '#ff6b6b';
                document.querySelector('.timer').style.fontWeight = 'bold';
            }
            
            // 验证码过期，刷新页面
            if (timeLeft <= 0) {
                location.reload();
            }
        }
        
        // 初始化进度条
        document.getElementById('progressBar').style.width = ((timeLeft / 30) * 100) + '%';
        
        // 每秒更新
        setInterval(updateTimer, 1000);
    </script>
</body>
</html>
